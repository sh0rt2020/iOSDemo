//
//  GSAnimateView.h
//  CoreAnimationDemo
//
//  Created by iosdevlope on 2017/6/7.
//  Copyright © 2017年 sunwell. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GSAnimateView : UIView

@end
